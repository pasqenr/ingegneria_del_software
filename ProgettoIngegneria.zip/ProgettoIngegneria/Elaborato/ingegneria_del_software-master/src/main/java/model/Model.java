package model;

public abstract class Model implements GenericDAO {
}
